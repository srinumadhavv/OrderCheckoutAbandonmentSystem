import {send_email} from './helper.js'
export const handler = async(event)=> {
    console.log(JSON.stringify(event, null, 2));
    for (let record of event.Records){
        console.log(record.eventID);
        console.log(record.eventName);
        console.log('DynamoDB Record: %j', record.dynamodb);
        console.log("email",record.dynamodb.Keys.email.S,typeof(record.dynamodb.Keys.email.S))
        // console.log('event.Records[0].userIdentity.type',event.Records[0]?.userIdentity?.type);
        // if(record.eventName==='REMOVE' && event.Records[0]?.userIdentity?.type === 'Service' && event.Records[0]?.userIdentity?.principalId === 'dynamodb.amazonaws.com')
        if(true){
            await send_email(record.dynamodb.Keys.email.S,"ITEMS WAITING IN CART","YOU ARE HAVING SOME AMAZING ITEMS IN YOUR CART WHICH MIGHT BE OUT OF STOCK SOON...").catch((err) => {
                console.log("mail not sent" + err.message);
              });
            console.log("EMAIL SENT");
        }
    }
    // await event.Records.forEach(async function(record) {
    //     console.log(record.eventID);
    //     console.log(record.eventName);
    //     console.log('DynamoDB Record: %j', record.dynamodb);
    //     console.log("email",record.dynamodb.Keys.email.S,typeof(record.dynamodb.Keys.email.S))
    //     // console.log('event.Records[0].userIdentity.type',event.Records[0]?.userIdentity?.type);
    //     // if(record.eventName==='REMOVE' && event.Records[0]?.userIdentity?.type === 'Service' && event.Records[0]?.userIdentity?.principalId === 'dynamodb.amazonaws.com')
    //     if(true){
    //         await send_email(record.dynamodb.Keys.email.S,"ITEMS WAITING IN CART","YOU ARE HAVING SOME AMAZING ITEMS IN YOUR CART WHICH MIGHT BE OUT OF STOCK SOON...").catch((err) => {
    //             console.log("mail not sent" + err.message);
    //           });
    //         console.log("EMAIL SENT");
    //     }
    // });
    console.log("SUCCESSFULLY PROCESSED")
    return
};
